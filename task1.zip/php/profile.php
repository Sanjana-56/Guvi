<?php
require 'C:/xampp/htdocs/task1/vendor/autoload.php';
use Predis\Client;
use MongoDB\Client as MongoClient;

session_start();

$redis = new Client([
    'scheme' => 'tcp',
    'host'   => '127.0.0.1',
    'port'   => 6379,
]);

$mongoClient = new MongoClient("mongodb://localhost:27017");
$db = $mongoClient->intern;
$collection = $db->profiles;

$data = json_decode(file_get_contents('php://input'), true);
$token = isset($data['token']) ? $data['token'] : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Token not found']);
    exit();
}

$email = base64_decode($token);

if (!$email) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit();
}

$storedEmail = $redis->get("auth_token:$token");

if ($storedEmail !== $email) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($data['action'] == 'fetch') {
    $profile = $redis->hgetall("user:$email");

    if (empty($profile)) {
        $user = $collection->findOne(['email' => $email]);
        if ($user) {
            if (isset($user['name'])) {
                $redis->hmset("user:$email", [
                    'name' => $user['name'],
                    'surname' => $user['surname'],
                    'age' => $user['age'],
                    'dob' => $user['dob'],
                    'mobileNumber' => $user['mobileNumber'],
                    'address' => $user['address'],
                    'country' => $user['country'],
                    'state' => $user['state']
                ]);

                $redis->expire("user:$email", 3600);

                $profile = [
                    'name' => $user['name'],
                    'surname' => $user['surname'],
                    'age' => $user['age'],
                    'dob' => $user['dob'],
                    'mobileNumber' => $user['mobileNumber'],
                    'email' => $user['email'],
                    'address' => $user['address'],
                    'country' => $user['country'],
                    'state' => $user['state']
                ];
                echo json_encode(['success' => true, 'profile' => $profile]);
            } else {
                echo json_encode(['success' => true, 'profile' => ['email' => $user['email']]]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Profile not found.']);
        }
    } else {
        $profile['email'] = $email;
        echo json_encode(['success' => true, 'profile' => $profile]);
    }
} elseif ($data['action'] == 'update') {
    $updateResult = $collection->updateOne(
        ['email' => $email],
        ['$set' => [
            'name' => $data['name'],
            'surname' => $data['surname'],
            'age' => $data['age'],
            'dob' => $data['dob'],
            'mobileNumber' => $data['mobileNumber'],
            'address' => $data['address'],
            'country' => $data['country'],
            'state' => $data['state']
        ]],
        ['upsert' => true]
    );

    if ($updateResult->getModifiedCount() > 0 || $updateResult->getUpsertedCount() > 0) {
        $redis->hmset("user:$email", [
            'name' => $data['name'],
            'surname' => $data['surname'],
            'age' => $data['age'],
            'dob' => $data['dob'],
            'mobileNumber' => $data['mobileNumber'],
            'address' => $data['address'],
            'country' => $data['country'],
            'state' => $data['state']
        ]);

        echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update profile.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
}
?>
