<?php

require 'C:/xampp/htdocs/task1/vendor/autoload.php';
use MongoDB\Client;

$mongoClient = new Client("mongodb://localhost:27017");
$mongoDbName = "intern";
$mongoCollectionName = "profiles"; 
$collection = $mongoClient->$mongoDbName->$mongoCollectionName;

$host = "localhost";
$username = "root";
$password = "";
$dbname = "phpmyadmin";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}

$response = array('success' => false);

if (isset($_POST['checkUsername'])) {
    $username = $_POST['checkUsername'];
    $stmt = $conn->prepare("SELECT COUNT(*) FROM task1 WHERE user = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $count = $stmt->fetchColumn();
    $response['success'] = $count == 0;
    echo json_encode($response);
    exit;
}

if (isset($_POST['checkEmail'])) {
    $email = $_POST['checkEmail'];
    $stmt = $conn->prepare("SELECT COUNT(*) FROM task1 WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $count = $stmt->fetchColumn();
    $response['success'] = $count == 0;
    echo json_encode($response);
    exit;
}

if (isset($_POST['name']) && !empty($_POST['name']) && isset($_POST['password']) && !empty($_POST['password']) && isset($_POST['email']) && !empty($_POST['email'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    try {
        $stmt = $conn->prepare("INSERT INTO task1 (user, pass, email) VALUES (:name, :password, :email)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':email', $email);

        if ($stmt->execute()) {
            $insertResult = $collection->insertOne(['email' => $email]);

            if ($insertResult->getInsertedCount() > 0) {
                $response['success'] = true;
            } else {
                $response['message'] = "Error inserting email into MongoDB.";
            }
        } else {
            $response['message'] = "Error inserting data into MySQL.";
        }
    } catch (PDOException $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response["message"] = "Please provide required details.";
}

echo json_encode($response);
?>
