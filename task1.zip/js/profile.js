$(document).ready(function() {
    function fetchUserProfile() {
        var authToken = localStorage.getItem('authToken');
        console.log('Authorization:', authToken);

        if (!authToken) {
            alert('No authentication token found.');
            window.location.href = 'http://localhost/task1/login.html';
            return; // Stop further execution if no token
        }

        $.ajax({
            url: 'http://localhost/task1/php/profile.php',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ token: authToken, action: 'fetch' }),
            success: function(response) {
                var res = JSON.parse(response);
                if (res.success) {
                    $('#email').val(res.profile.email).attr('readonly', true);

                    if (res.profile.name) {
                        $('#name').val(res.profile.name);
                        $('#surname').val(res.profile.surname);
                        $('#age').val(res.profile.age);
                        $('#dob').val(res.profile.dob);
                        $('#mobileNumber').val(res.profile.mobileNumber);
                        $('#address').val(res.profile.address);
                        $('#country').val(res.profile.country);
                        $('#state').val(res.profile.state);
                    }
                } else {
                    alert(res.message);
                    window.location.href = 'http://localhost/task1/login.html';
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                alert('Error fetching profile details.');
                window.location.href = 'http://localhost/task1/login.html';
            }
        });
    }

    function validateMobileNumber() {
        var mobileNumber = $('#mobileNumber').val();
        var mobileError = $('#mobileError');

        if (mobileNumber && !/^\d{10}$/.test(mobileNumber)) {
            mobileError.text('Provide a valid mobile number with 10 digits.');
            return false;
        } else {
            mobileError.text('');
            return true;
        }
    }

    function validateDOB() {
        var dob = $('#dob').val();
        var dobError = $('#dobError');

        if (dob && !/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
            dobError.text('Provide a valid date of birth in YYYY-MM-DD format.');
            return false;
        } else {
            dobError.text('');
            return true;
        }
    }

    $('#mobileNumber').blur(validateMobileNumber);
    $('#dob').blur(validateDOB);

    $('#saveProfile').click(function() {
        var isMobileValid = validateMobileNumber();
        var isDobValid = validateDOB();

        if (!isMobileValid || !isDobValid) {
            return; 
        }

        var authToken = localStorage.getItem('authToken');
        var profileData = {
            token: authToken,
            action: 'update',
            name: $('#name').val(),
            surname: $('#surname').val(),
            age: $('#age').val(),
            dob: $('#dob').val(),
            mobileNumber: $('#mobileNumber').val(),
            email: $('#email').val(),
            address: $('#address').val(),
            country: $('#country').val(),
            state: $('#state').val()
        };

        $.ajax({
            url: 'http://localhost/task1/php/profile.php',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(profileData),
            success: function(response) {
                var res = JSON.parse(response);
                if (res.success) {
                    $('#responseMessage').text('Profile updated successfully.').css('color', 'green');
                    window.location.href = 'http://localhost/task1/index.html';
                } else {
                    $('#responseMessage').text(res.message).css('color', 'red');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                $('#responseMessage').text('Error updating profile details.').css('color', 'red');
                window.location.href = 'http://localhost/task1/login.html';
            }
        });
    });

    fetchUserProfile();
});
