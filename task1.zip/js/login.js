$(document).ready(function() {
    $('#loginForm').on('submit', function(event) {
        event.preventDefault();
        submitForm();
    });

    $('#email').on('blur', function() {
        var email = $(this).val();
        checkEmail(email);
    });
});

function checkEmail(email) {
    if (email === '') {
        $('#email-error').text('Email is required');
        return;
    }

    $.ajax({
        url: "http://localhost/task1/php/login.php",
        type: 'POST',
        data: { action: 'check_email', email: email },
        success: function(response) {
            console.log('checkEmail response:', response);
            var res = JSON.parse(response);
            if (!res.success) {
                $('#email-error').text(res.message);
            } else {
                $('#email-error').text('');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('AJAX error:', textStatus, errorThrown);
        }
    });
}

function submitForm() {
    var email = $('#email').val();
    var password = $('#pass').val();

    if (email === '') {
        $('#email-error').text('Email is required');
        return;
    }

    if (password === '') {
        $('#pass-error').text('Password is required');
        return;
    }

    $.ajax({
        url: "http://localhost/task1/php/login.php",
        type: 'POST',
        data: { email: email, password: password },
        success: function(response) {
            console.log('submitForm response:', response);
            var res = JSON.parse(response);

            if (res.success) {
                localStorage.setItem('authToken', res.token);  
                window.location.href = 'http://localhost/task1/profile.html';
            } else {
                if (res.errorField === 'email') {
                    $('#email-error').text(res.message);
                    $('#pass-error').text('');
                } else if (res.errorField === 'password') {
                    $('#pass-error').text(res.message);
                    $('#email-error').text('');
                } else {
                    $('#email-error').text('');
                    $('#pass-error').text('');
                    alert(res.message);
                }
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('AJAX error:', textStatus, errorThrown);
        }
    });
}
